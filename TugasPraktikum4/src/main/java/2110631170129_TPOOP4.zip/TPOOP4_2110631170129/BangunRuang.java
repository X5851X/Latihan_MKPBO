/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TPOOP4_2110631170129;

/**
 *
 * @author Risvandiani
 */
public class BangunRuang {
    int hitungluas(){
        System.out.println("Menghitung luas bangun ruang");
        return 0;
}
    int hitungkeliling(){
        System.out.println("Menghitung keliling bangun ruang");
        return 0;
    }
}
